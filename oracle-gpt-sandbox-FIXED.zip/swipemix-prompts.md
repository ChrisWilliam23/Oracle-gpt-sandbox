# SwipeMix IG Prompts

**Post A:**  
"Movement is the scent of the soul."  
📸 Visual: Ceremony altar, white fabric + candle  
🎵 Audio: Ambient flutes

**Post B:**  
"What if fragrance was your compass?"  
📸 Visual: 3139 bottle in hand, outdoors  
🎵 Audio: Nature or poetic monologue
