# The Oracle of Ojas

A poetic assistant infused with scent wisdom, creative ceremony, and launch alignment.

This repository is the sacred sandbox for:
- Prompt flows used by The Oracle of Ojas GPT assistant
- Launch workflows, SOPs, and VA tasks
- Brand voice, content guides, and scent stories
