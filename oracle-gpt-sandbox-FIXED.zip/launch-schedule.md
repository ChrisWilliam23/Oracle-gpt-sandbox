# Launch Schedule Template

| Week | Focus | Owner | Notes |
|------|-------|--------|-------|
| Week 1 | Sample Kits / SwipeMix Post #1 | Jennica | Feature poetic quote + bottle image |
| Week 2 | Oracle GPT Launch | Chris | Share link + onboarding guide |
| Week 3 | Ceremony Booking Page | Shiela | Test checkout flow |
