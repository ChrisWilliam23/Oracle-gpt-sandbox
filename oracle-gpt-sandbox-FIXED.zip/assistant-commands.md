# Assistant Command Flows

- "Switch to Team Mode" – activates VA support logic
- "Summarize launch tasks this week" – weekly breakdown from Notion
- "Draft a DM for a sample kit delay" – poetic customer follow-up
